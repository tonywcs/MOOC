from django.apps import AppConfig

class BasicPagesConfig(AppConfig):
    name = 'basic_pages'
